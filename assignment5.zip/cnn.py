#!/usr/bin/env python3
# -*- coding: utf-8 -*-

### YOUR CODE HERE for part 1e

import torch
import torch.nn as nn
import torch.nn.functional as F

class CNN(nn.Module):
    
    def __init__(self, in_channels, out_channels, max_words, kernel_size=5, bias=True, layers=1):
        """
        Init the character CNN module
        :param in_channels (int): embedding size of each character in a word
        :param out_channels (int): No of filters or word_embed_size
        :param max_words (int): maximum length of a word
        :param kernel_size (int): length convolve of each kernel
        :param bias (bool): bias to be added or not in Conv1d
        """
        super(CNN, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.max_words = max_words
        self.kernel_size = kernel_size
        self.bias = bias
        self.layers = layers
        if self.layers == 1:
            self.conv1d_layerN = nn.ModuleList([nn.Conv1d(in_channels = self.in_channels, # char embedding size
                                    out_channels = self.out_channels, # no. of. Filters
                                    kernel_size = self.kernel_size, 
                                    bias=self.bias) for _ in range(layers)])
        else:
            self.conv1d_layerN = nn.ModuleList([nn.Conv1d(in_channels = self.in_channels, # char embedding size
                                    out_channels = self.out_channels, # no. of. Filters
                                    kernel_size = self.kernel_size, 
                                    bias=self.bias) for _ in range(layers-1)])
            self.conv1d_LayerIterateF = nn.ModuleList([nn.Conv1d(in_channels = self.in_channels, # char embedding size
                                    out_channels = (self.in_channels*2), # no. of. Filters
                                    kernel_size = 1, 
                                    bias=self.bias) for _ in range(layers-1)])
            self.conv1d_LayerIterateB = nn.ModuleList([nn.Conv1d(in_channels = (self.in_channels*2), # char embedding size
                                    out_channels = self.in_channels, # no. of. Filters
                                    kernel_size = 1, 
                                    bias=self.bias) for _ in range(layers-1)])
                
        self.max_pool_1d = nn.MaxPool1d(self.max_words - self.kernel_size + 1) 
        
        
    def forward(self, input):
        """
        Take a mini batch of character embedding of each word, compute word embedding
        :param input (Tensor): shape (batch_size, in_channels (char embedding size), max_words)
        :return (Tensor): shape (batch_size, out_channels), word embedding of each word in batch
        """
        x = input[:]
        if self.layers == 1:
            for layer in range(self.layers):
                x = self.conv1d_layerN[layer](x) # (batch_size, word_embed_size/No.of Filters, max_words - kernel_size + 1)
                #x = F.relu_(x)
                #x = self.max_pool_1d[layer](x)
        else:
            for layer in range(self.layers-1):
                x = self.conv1d_LayerIterateF[layer](x) # (batch_size, word_embed_size/No.of Filters, max_words - kernel_size + 1)
                x = self.conv1d_LayerIterateB[layer](x)
            x = self.conv1d_layerN[layer](x)
        
        x = F.relu_(x)
        x = self.max_pool_1d(x)
        
        return x.squeeze()

### END YOUR CODE

