#!/usr/bin/env python3
# -*- coding: utf-8 -*-

### YOUR CODE HERE for part 1d

import torch
import torch.nn as nn
import torch.nn.functional as F

class Highway(nn.Module):
    
    def __init__(self, size, layers=1):
        super(Highway, self).__init__()
        """
        input @size: both input and output are defined with same size.
        @layers: number of layers
        """
        self.layers = layers
        self.linear = nn.ModuleList([nn.Linear(size, size) for _ in range(layers)])
        self.gate = nn.ModuleList([nn.Linear(size, size) for _ in range(layers)])
        
    def forward(self, conv_output: torch.Tensor) -> torch.Tensor:
        """
        input: @conv_output: tensor (output of the convolution)
        return: same shape of the input tensor
        """
        x = conv_output[:]
        for layer in range(self.layers):
            gate = torch.sigmoid(self.gate[layer](x))
            nonlinear = F.relu(self.linear[layer](x))
            
            x = ((gate * nonlinear) + ((1 - gate) * conv_output))
        
        return x
        

### END YOUR CODE 

